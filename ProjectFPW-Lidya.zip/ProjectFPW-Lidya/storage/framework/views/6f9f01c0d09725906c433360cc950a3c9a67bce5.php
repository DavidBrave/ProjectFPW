<?php $__env->startSection('menu_bar'); ?>
    <li><a href="/murid_home">Home</a></li>
    <li><a href="/daftar_kelas">Course</a></li>
    <li><a href="/kelas_yg_diambil">Daftar Les yang Diambil</a></li>
    <li><a href="/murid_profil">Profil</a></li>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Documents\sem5\fpw\ProjekFPW\Lidya\ProjectFPW-Lidya\resources\views/includes/headerMurid.blade.php ENDPATH**/ ?>