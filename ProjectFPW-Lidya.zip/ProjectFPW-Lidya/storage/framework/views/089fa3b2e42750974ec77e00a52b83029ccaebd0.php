<?php $__env->startSection('menu_bar'); ?>
    <li><a href="/" id="home">Home</a></li>
    <li><a href="/about" id="about">About Smart Course</a></li>
    <li><a href="/courses" id="courses">Courses</a></li>
    <li><a href="/login" id="login">Login</a></li>
    <li><a href="/register" id="register">Register</a></li>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Documents\sem5\fpw\ProjekFPW\Lidya\ProjectFPW-Lidya\resources\views/includes/menuBarNonUser.blade.php ENDPATH**/ ?>