<br><br>
<button><a href="/murid_home">Home</a></button>
<button><a href="/kelas_yg_diambil">Daftar Les yang Diambil</a></button>
<button><a href="/murid_profil">Profil</a></button>
</form>
<?php /**PATH C:\Users\Asus\Documents\sem5\fpw\ProjekFPW\Lidya\ProjectFPW-Lidya\resources\views/murid/menu_bar.blade.php ENDPATH**/ ?>