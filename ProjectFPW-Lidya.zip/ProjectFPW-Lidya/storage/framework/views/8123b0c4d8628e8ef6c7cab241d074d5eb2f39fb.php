<style>
    #footer{
        background-color: #bfe6ff;
        color:  #1f333f;
        font-size: 15px;
        text-align: center;
        line-height: 50px;
    }
</style>
<div id="footer">
    <p>Copyright © 2019  Smart Course. All rights reserved.  Kursus Bimbel Surabaya</p>
</div>
<?php /**PATH C:\Users\Asus\Documents\sem5\fpw\ProjekFPW\Lidya\ProjectFPW-Lidya\resources\views/includes/footer.blade.php ENDPATH**/ ?>