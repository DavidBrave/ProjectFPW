<?php $__env->startSection('content'); ?>
    <h1>Profil</h1>
    <form action="/murid_edit_profil" method="get">
        <button name="btnEditProfil" value="1">Edit Profil</button>
    </form>
    <table>
        <tr>
            <td>Username</td>
            <td>: <?php echo e($murid->Murid_Username); ?></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td>: <?php echo e($murid->Murid_Nama); ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td>: <?php echo e($murid->Murid_Email); ?></td>
        </tr>
        <tr>
            <td>Tingkat Pendidikan</td>
            <td>: <?php echo e($murid->tingkatan->Pendidikan_Keterangan); ?></td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('murid.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Documents\sem5\fpw\ProjekFPW\Lidya\ProjectFPW-Lidya\resources\views/murid/components/Profil.blade.php ENDPATH**/ ?>