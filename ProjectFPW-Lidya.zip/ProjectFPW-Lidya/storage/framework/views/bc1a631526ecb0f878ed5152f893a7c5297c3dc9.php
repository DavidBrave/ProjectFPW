<?php $__env->startSection('content'); ?>
    <br><br><br><br>
    <h1>Welcome , <?php echo e($murid->Murid_Username); ?></h1>
    <h2>Daftar Kelas</h2>
    <hr>
        <?php $__currentLoopData = $les; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3><?php echo e($item->Nama); ?></h3>
            Diajar oleh <?php echo e($item->guru->Guru_Nama); ?>

            <table>
                <tr>
                    <td>Mata Pelajaran</td>
                    <td>: <?php echo e($item->pelajaran->Pelajaran_Nama); ?></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Tingkat</td>
                    <td>: <?php echo e($item->tingkatan->Pendidikan_Keterangan); ?></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Sisa slot </td>
                    <td>: <?php echo e($item->Sisa_Slot); ?> dari <?php echo e($item->Slot); ?></td>
                    <td>
                        <form action="/set_session_kelas" method="get">
                            <button type="submit"
                            value="<?php echo e($item->Les_ID); ?>" name="btnDetail"> Lihat Detail</button>
                        </form>
                    </td>
                </tr>
            </table>
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('murid.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Documents\sem5\fpw\ProjekFPW\Lidya\ProjectFPW-Lidya\resources\views/murid/components/DaftarLes.blade.php ENDPATH**/ ?>