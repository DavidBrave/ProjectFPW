<!DOCTYPE html>

<?php $__env->startSection('content'); ?>
    <h2>Welcome,<?php echo e($username); ?></h2>
    
    <?php echo $__env->make('isiHome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('murid.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Documents\sem5\fpw\ProjekFPW\Lidya\ProjectFPW-Lidya\resources\views/murid/components/HomeMurid.blade.php ENDPATH**/ ?>