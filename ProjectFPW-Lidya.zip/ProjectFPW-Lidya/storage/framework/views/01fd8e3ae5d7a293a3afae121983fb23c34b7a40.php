<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="resources\js\jquery-3.4.1.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset("materialize/css/materialize.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("jquery.js")); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
</head>
<style>
    .checked {
        color: orange;
    }
    body{
        background-color: #bfe6ff;
    }
    #container{
        display: grid;
        grid-template-rows: 120px 900px 100px;
    }
</style>
<body>
    <div id="container">
        <?php echo $__env->make('includes.headerMurid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Asus\Documents\sem5\fpw\ProjekFPW\Lidya\ProjectFPW-Lidya\resources\views/murid/home.blade.php ENDPATH**/ ?>