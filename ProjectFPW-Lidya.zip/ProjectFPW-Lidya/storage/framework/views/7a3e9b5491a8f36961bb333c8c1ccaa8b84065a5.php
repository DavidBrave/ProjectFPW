<?php $__env->startSection('content'); ?>
    <h1>Daftar Les yang Diambil</h1>
    <?php if(count($leslesan)==0): ?>
        <h2>Belum Mengambil Les Apapun</h2>
    <?php else: ?>
    <table>
        <?php $__currentLoopData = $leslesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $les): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><h2><?php echo e($les->Nama); ?></h2></td>
            </tr>
            <tr>
            <td>Nama Guru Les</td>
            <td>: <?php echo e($les->guru->Guru_Nama); ?></td>
            </tr>
            <tr>
            <td>Nama Pelajaran</td>
            <td>: <?php echo e($les->pelajaran->Pelajaran_Nama); ?></td>
            </tr>
            <tr>
                <td>Status</td>
                <?php if($les->pivot->Pengambilan_Status != 2): ?>
                    <td>: Sedang Mengikuti</td>
                <?php else: ?>
                    <?php if($les->pivot->Pengambilan_Status == 0): ?>
                        <td>: Sedang Dikonfirmasi untuk Join</td>
                    <?php else: ?>
                        <td>: Permintaan untuk Join Ditolak</td>
                    <?php endif; ?>
                <?php endif; ?>
            </tr>
            <tr>
                <td></td>
            <td>
                <form action="/set_session_kelas_diambil" method="get">
                    <button type="submit" name = "btnDetail" value="<?php echo e($les->Les_ID); ?>">Lihat Detail</button>
                </form>
            </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('murid.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Documents\sem5\fpw\ProjekFPW\Lidya\ProjectFPW-Lidya\resources\views/murid/components/LesYgDiambil.blade.php ENDPATH**/ ?>