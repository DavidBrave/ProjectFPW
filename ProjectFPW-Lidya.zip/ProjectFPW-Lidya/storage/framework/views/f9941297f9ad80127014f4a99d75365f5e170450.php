<?php $__env->startSection('content'); ?>

<h1>Detail Les</h1>
    <br>
    <h2><?php echo e($les->Nama); ?></h2>
    Diajar Oleh <?php echo e($les->guru->Guru_Nama); ?> <br>
    <?php if($les->Jum_Orang_Rating == 0): ?>
        Belum dirating
    <?php else: ?>
        Rating : <?php echo e($les->Rating); ?> dari 5 dari <?php echo e($les->Jum_Orang_Rating); ?> Suara
    <?php endif; ?>
    <br>
    <?php if($les->pivot->Pengambilan_Status != 2 ): ?>
        Status :
        <?php if($les->pivot->Pengambilan_Status == 0): ?>
            Permintaan join les belum dikonfirmasi
        <?php else: ?>
            Permintaan join les ditolak
        <?php endif; ?>
        <form action="/murid_batal_ajukan_join_les" method="get">
            <button type="submit"
            onclick="return confirm('Apakah anda yakin akan membatalkan permintaan untuk join di les ini?')"
            >Membatalkan permintaan untuk join les</button>
        </form>
    <?php else: ?>
        Status : Sedang Mengikuti
        <form action="/murid_rating_kelas" method="get">
            <button type="submit"
            onclick="return confirm('Apakah anda yakin akan keluar dari les ini?')"
            >Keluar Les</button>
        </form>
    <?php endif; ?>

    <table>
        <tr>
            <td>Mata Pelajaran yang diajarkan</td>
            <td>: <?php echo e($les->pelajaran->Pelajaran_Nama); ?></td>
        </tr>
        <tr>
            <td>Tingkat Pendidikan</td>
            <td>: <?php echo e($les->tingkatan->Pendidikan_Keterangan); ?></td>
        </tr>
        <tr>
            <td>Sisa slot </td>
            <td>: <?php echo e($les->Sisa_Slot); ?> dari <?php echo e($les->Slot); ?></td>
        </tr>
    </table>
    Deskripsi : <br>
    <?php echo e($les->Deskripsi); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('murid.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Documents\sem5\fpw\ProjekFPW\Lidya\ProjectFPW-Lidya\resources\views/murid/components/DetailLesDiambil.blade.php ENDPATH**/ ?>