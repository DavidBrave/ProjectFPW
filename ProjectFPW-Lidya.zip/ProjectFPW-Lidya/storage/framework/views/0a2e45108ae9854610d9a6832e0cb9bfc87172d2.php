<?php $__env->startSection('content'); ?>
    <h1>Detail Les</h1>
    <br>
    <h2><?php echo e($les->Nama); ?></h2>
    Diajar Oleh <?php echo e($les->guru->Guru_Nama); ?> <br>
    <?php if($les->Jum_Orang_Rating == 0): ?>
        Belum dirating
    <?php else: ?>
        Rating : <?php echo e($les->Rating); ?> dari 5 dari <?php echo e($les->Jum_Orang_Rating); ?> Suara
    <?php endif; ?>
    <table>
        <tr>
            <td>Mata Pelajaran yang diajarkan</td>
            <td>: <?php echo e($les->pelajaran->Pelajaran_Nama); ?></td>
        </tr>
        <tr>
            <td>Tingkat Pendidikan</td>
            <td>: <?php echo e($les->tingkatan->Pendidikan_Keterangan); ?></td>
        </tr>
        <tr>
            <td>Sisa slot </td>
            <td>: <?php echo e($les->Sisa_Slot); ?> dari <?php echo e($les->Slot); ?></td>
        </tr>
    </table>
    Deskripsi : <br>
    <?php echo e($les->Deskripsi); ?>


    <br>

    <?php if(count($lesDiambil)==0): ?>
        <form action="/ambilKelas" method="post">
            <?php echo csrf_field(); ?>
            <button type="submit">Ajukan Pengambilan</button>
        </form>
    <?php else: ?>
        Status : Kelas Sudah Diambil
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('murid.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Documents\sem5\fpw\ProjekFPW\Lidya\ProjectFPW-Lidya\resources\views/murid/components/DetailLes.blade.php ENDPATH**/ ?>