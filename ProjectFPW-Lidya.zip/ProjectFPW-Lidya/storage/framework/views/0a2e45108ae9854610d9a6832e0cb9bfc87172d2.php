<?php $__env->startSection('content'); ?>

    <?php if(session("message")!=null): ?>
        <script>alert("<?php echo e(session('message')); ?>");</script>
    <?php endif; ?>
    <h1>Detail Les</h1>
    <br>
    <h2><?php echo e($les->Nama); ?></h2>
    Diajar Oleh <?php echo e($les->guru->Guru_Nama); ?> <br>
    <?php if($les->Jum_Orang_Rating == 0): ?>
        Belum dirating
    <?php else: ?>
        Rating : <?php echo e($les->Rating); ?> dari 5 dari <?php echo e($les->Jum_Orang_Rating); ?> Suara
    <?php endif; ?>
    <?php if($lesDiambil==null): ?>
        <form action="/murid_ambil_kelas" method="get">
            <button type="submit">Ajukan Pengambilan</button>
        </form>
    <?php endif; ?>
    <table>
        <tr>
            <td>Mata Pelajaran yang diajarkan</td>
            <td>: <?php echo e($les->pelajaran->Pelajaran_Nama); ?></td>
        </tr>
        <tr>
            <td>Tingkat Pendidikan</td>
            <td>: <?php echo e($les->tingkatan->Pendidikan_Keterangan); ?></td>
        </tr>
        <tr>
            <td>Sisa slot </td>
            <td>: <?php echo e($les->Sisa_Slot); ?> dari <?php echo e($les->Slot); ?></td>
        </tr>
    </table>
    Deskripsi : <br>
    <?php echo e($les->Deskripsi); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('murid.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Asus\Documents\sem5\fpw\ProjekFPW\Lidya\ProjectFPW-Lidya\resources\views/murid/components/DetailLes.blade.php ENDPATH**/ ?>