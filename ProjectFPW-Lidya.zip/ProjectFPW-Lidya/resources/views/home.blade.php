@extends('mainpage')
@section('content')
@include('isiHome')
@endsection
