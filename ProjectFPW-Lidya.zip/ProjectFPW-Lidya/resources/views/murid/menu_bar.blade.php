<br><br>
<button><a href="/murid_home">Home</a></button>
<button><a href="/kelas_yg_diambil">Daftar Les yang Diambil</a></button>
<button><a href="/murid_profil">Profil</a></button>
</form>
