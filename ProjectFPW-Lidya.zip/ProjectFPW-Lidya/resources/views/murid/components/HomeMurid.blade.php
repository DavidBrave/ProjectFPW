<!DOCTYPE html>
@extends('murid.home')
@section('content')
    <h2>Welcome,{{$username}}</h2>
    {{-- Menampilkan notifikasi chat bila ada
        <h2>Notifikasi Chat</h2>
    --}}
    @include('isiHome')
@endsection

