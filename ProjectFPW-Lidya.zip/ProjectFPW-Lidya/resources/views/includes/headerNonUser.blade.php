@extends('includes.header')
@section('menu_bar')
    <li><a href="/" id="home">Home</a></li>
    <li><a href="/about" id="about">About Smart Course</a></li>
    <li><a href="/courses" id="courses">Courses</a></li>
    <li><a href="/login" id="login">Login</a></li>
    <li><a href="/register" id="register">Register</a></li>
@endsection
