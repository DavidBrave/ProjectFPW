@extends('includes.header')
@section('menu_bar')
    <li><a href="/murid_home">Home</a></li>
    <li><a href="/daftar_kelas">Course</a></li>
    <li><a href="/kelas_yg_diambil">Daftar Les yang Diambil</a></li>
    <li><a href="/murid_profil">Profil</a></li>
@endsection

